import React, { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box, Typography, Card, CardContent, LinearProgress,
  TextField, MenuItem, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, IconButton,
  Tooltip, InputAdornment, Button, Dialog, DialogTitle,
  DialogContent, DialogActions, Checkbox, Alert, Snackbar,
  Badge, Stack,
} from '@mui/material'
import SearchIcon from '@mui/icons-material/Search'
import RefreshIcon from '@mui/icons-material/Refresh'
import OpenInNewIcon from '@mui/icons-material/OpenInNew'
import AssessmentIcon from '@mui/icons-material/Assessment'
import AttachFileIcon from '@mui/icons-material/AttachFile'
import UploadFileIcon from '@mui/icons-material/UploadFile'
import CalendarTodayIcon from '@mui/icons-material/CalendarToday'
import CloseIcon from '@mui/icons-material/Close'
import { getRuns } from '../api/runs'
import StatusChip from '../components/StatusChip'
import dayjs from 'dayjs'

const STATUS_OPTIONS = ['TOUS', 'SUCCESS', 'FAILED', 'RUNNING', 'PENDING', 'CANCELLED']

export default function RunsHistoryPage() {
  const navigate = useNavigate()
  const fileInputRef = useRef(null)

  const [runs, setRuns]                   = useState([])
  const [loading, setLoading]             = useState(true)
  const [search, setSearch]               = useState('')
  const [statusFilter, setStatusFilter]   = useState('TOUS')
  const [dateFrom, setDateFrom]           = useState('')
  const [dateTo, setDateTo]               = useState('')

  // Attachment dialog state
  const [attachOpen, setAttachOpen]       = useState(false)
  const [selectedRuns, setSelectedRuns]   = useState(new Set())
  const [attachedFile, setAttachedFile]   = useState(null)
  const [attachNote, setAttachNote]       = useState('')
  const [snackbar, setSnackbar]           = useState({ open: false, message: '', severity: 'success' })

  const load = () => {
    setLoading(true)
    getRuns()
      .then(data => setRuns(Array.isArray(data) ? data : []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }
  useEffect(load, [])

  const filtered = runs.filter(r => {
    const matchStatus = statusFilter === 'TOUS' || r.status === statusFilter
    const matchSearch = !search ||
      r.simulationClass?.toLowerCase().includes(search.toLowerCase()) ||
      r.project?.name?.toLowerCase().includes(search.toLowerCase()) ||
      r.launchedBy?.toLowerCase().includes(search.toLowerCase())
    const runDate = dayjs(r.startedAt)
    const matchFrom = !dateFrom || runDate.isAfter(dayjs(dateFrom).subtract(1, 'day'))
    const matchTo   = !dateTo   || runDate.isBefore(dayjs(dateTo).add(1, 'day'))
    return matchStatus && matchSearch && matchFrom && matchTo
  })

  const stats = {
    total:   runs.length,
    success: runs.filter(r => r.status === 'SUCCESS').length,
    failed:  runs.filter(r => r.status === 'FAILED').length,
    running: runs.filter(r => r.status === 'RUNNING').length,
  }

  // --- Attachment dialog helpers ---
  const openAttachDialog = () => {
    setSelectedRuns(new Set())
    setAttachedFile(null)
    setAttachNote('')
    setAttachOpen(true)
  }

  const toggleRunSelection = (id) => {
    setSelectedRuns(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const toggleAll = () => {
    if (selectedRuns.size === filtered.length) {
      setSelectedRuns(new Set())
    } else {
      setSelectedRuns(new Set(filtered.map(r => r.id)))
    }
  }

  const handleFileChange = (e) => {
    const file = e.target.files?.[0]
    if (file) setAttachedFile(file)
  }

  const handleAttachSubmit = () => {
    if (!attachedFile) {
      setSnackbar({ open: true, message: 'Veuillez sélectionner un fichier.', severity: 'warning' })
      return
    }
    if (selectedRuns.size === 0) {
      setSnackbar({ open: true, message: 'Veuillez sélectionner au moins une exécution.', severity: 'warning' })
      return
    }

    // TODO: call your API — e.g. uploadAttachment({ runIds: [...selectedRuns], file: attachedFile, note: attachNote })
    console.log('Attaching', attachedFile.name, 'to runs', [...selectedRuns], 'note:', attachNote)

    setSnackbar({
      open: true,
      message: `"${attachedFile.name}" associé à ${selectedRuns.size} exécution(s).`,
      severity: 'success',
    })
    setAttachOpen(false)
  }

  const clearDateFilters = () => { setDateFrom(''); setDateTo('') }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>Historique des simulations</Typography>
          <Typography variant="body2" color="text.secondary">
            {stats.total} exécutions · {stats.success} succès · {stats.failed} échecs
            {stats.running > 0 && ` · ${stats.running} en cours`}
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Button
            variant="outlined"
            startIcon={<AttachFileIcon />}
            onClick={openAttachDialog}
            size="small"
          >
            Ajouter une pièce jointe
          </Button>
          <Tooltip title="Rafraîchir">
            <IconButton onClick={load}><RefreshIcon /></IconButton>
          </Tooltip>
        </Stack>
      </Box>

      {loading && <LinearProgress sx={{ mb: 2 }} />}

      {/* Filters */}
      <Card sx={{ mb: 2 }}>
        <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            {/* Search */}
            <TextField
              size="small"
              placeholder="Rechercher simulation, projet, utilisateur..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              sx={{ minWidth: 300 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
                ),
              }}
            />

            {/* Status */}
            <TextField
              select size="small" label="Statut"
              value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
              sx={{ minWidth: 140 }}
            >
              {STATUS_OPTIONS.map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
            </TextField>

            {/* Date From */}
            <TextField
              size="small" type="date" label="Du"
              value={dateFrom} onChange={e => setDateFrom(e.target.value)}
              InputLabelProps={{ shrink: true }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start"><CalendarTodayIcon fontSize="small" /></InputAdornment>
                ),
              }}
              sx={{ minWidth: 170 }}
            />

            {/* Date To */}
            <TextField
              size="small" type="date" label="Au"
              value={dateTo} onChange={e => setDateTo(e.target.value)}
              InputLabelProps={{ shrink: true }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start"><CalendarTodayIcon fontSize="small" /></InputAdornment>
                ),
              }}
              sx={{ minWidth: 170 }}
            />

            {/* Clear date filters */}
            {(dateFrom || dateTo) && (
              <Tooltip title="Effacer les filtres de date">
                <IconButton size="small" onClick={clearDateFilters}>
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Box>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ '& .MuiTableCell-head': { fontWeight: 700, color: 'text.secondary', fontSize: '0.75rem' } }}>
                <TableCell>#</TableCell>
                <TableCell>PROJET</TableCell>
                <TableCell>SIMULATION</TableCell>
                <TableCell align="right">REQUÊTES</TableCell>
                <TableCell align="right">KO</TableCell>
                <TableCell align="right">TEMPS MOY.</TableCell>
                <TableCell align="right">DURÉE</TableCell>
                <TableCell>LANCÉ PAR</TableCell>
                <TableCell>DATE</TableCell>
                <TableCell>STATUT</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={11} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                    Aucune simulation trouvée.
                  </TableCell>
                </TableRow>
              )}
              {filtered.map(run => (
                <TableRow key={run.id} hover sx={{ cursor: 'pointer' }} onClick={() => navigate(`/runs/${run.id}`)}>
                  <TableCell sx={{ color: 'text.secondary', fontSize: '0.75rem' }}>#{run.id}</TableCell>
                  <TableCell>
                    <Typography variant="body2" fontWeight={500} noWrap sx={{ maxWidth: 140 }}>
                      {run.project?.name ?? '—'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" sx={{ fontFamily: 'monospace', display: 'block', maxWidth: 220 }} noWrap>
                      {run.simulationClass}
                    </Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Typography variant="body2">{run.totalRequests != null ? run.totalRequests.toLocaleString() : '—'}</Typography>
                  </TableCell>
                  <TableCell align="right">
                    {run.failedRequests != null
                      ? <Typography variant="body2" color={run.failedRequests > 0 ? 'error.main' : 'success.main'}>
                          {run.failedRequests.toLocaleString()}
                        </Typography>
                      : '—'}
                  </TableCell>
                  <TableCell align="right">
                    {run.meanResponseTime != null
                      ? <Chip
                          label={`${run.meanResponseTime} ms`} size="small"
                          color={run.meanResponseTime < 500 ? 'success' : run.meanResponseTime < 2000 ? 'warning' : 'error'}
                          variant="outlined"
                        />
                      : '—'}
                  </TableCell>
                  <TableCell align="right">
                    <Typography variant="caption" color="text.secondary">
                      {run.durationSeconds != null
                        ? `${Math.floor(run.durationSeconds / 60)}m ${run.durationSeconds % 60}s`
                        : '—'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" color="text.secondary">{run.launchedBy ?? '—'}</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" color="text.secondary">
                      {dayjs(run.startedAt).format('DD/MM/YY HH:mm')}
                    </Typography>
                  </TableCell>
                  <TableCell><StatusChip status={run.status} /></TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 0.5 }}>
                      {run.reportPath && (
                        <Tooltip title="Rapport Gatling">
                          <IconButton size="small" color="primary"
                            onClick={e => { e.stopPropagation(); navigate(`/runs/${run.id}`) }}>
                            <AssessmentIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      <Tooltip title="Voir les logs">
                        <IconButton size="small"
                          onClick={e => { e.stopPropagation(); navigate(`/runs/${run.id}`) }}>
                          <OpenInNewIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      {/* ── Attachment Dialog ── */}
      <Dialog open={attachOpen} onClose={() => setAttachOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <AttachFileIcon color="primary" />
          Ajouter une pièce jointe
        </DialogTitle>

        <DialogContent dividers>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Sélectionnez les exécutions auxquelles associer la pièce jointe, puis choisissez un fichier.
          </Typography>

          {/* File picker */}
          <Box
            sx={{
              border: '2px dashed',
              borderColor: attachedFile ? 'primary.main' : 'divider',
              borderRadius: 2,
              p: 3,
              textAlign: 'center',
              mb: 3,
              cursor: 'pointer',
              transition: 'border-color 0.2s',
              '&:hover': { borderColor: 'primary.light' },
            }}
            onClick={() => fileInputRef.current?.click()}
          >
            <input ref={fileInputRef} type="file" hidden onChange={handleFileChange} />
            <UploadFileIcon sx={{ fontSize: 40, color: attachedFile ? 'primary.main' : 'text.disabled', mb: 1 }} />
            {attachedFile
              ? <Typography variant="body2" fontWeight={600}>{attachedFile.name}</Typography>
              : <Typography variant="body2" color="text.secondary">
                  Cliquez pour sélectionner un fichier
                </Typography>
            }
            {attachedFile && (
              <Typography variant="caption" color="text.secondary">
                {(attachedFile.size / 1024).toFixed(1)} Ko
              </Typography>
            )}
          </Box>

          {/* Note */}
          <TextField
            fullWidth size="small" label="Note (optionnelle)"
            placeholder="Décrivez cette pièce jointe..."
            value={attachNote} onChange={e => setAttachNote(e.target.value)}
            multiline rows={2} sx={{ mb: 3 }}
          />

          {/* Run selection table */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
            <Typography variant="subtitle2">
              Exécutions ({filtered.length} disponibles)
            </Typography>
            <Typography
              variant="caption" color="primary" sx={{ cursor: 'pointer', userSelect: 'none' }}
              onClick={toggleAll}
            >
              {selectedRuns.size === filtered.length && filtered.length > 0 ? 'Tout désélectionner' : 'Tout sélectionner'}
            </Typography>
          </Box>

          <TableContainer sx={{ maxHeight: 320, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell padding="checkbox">
                    <Checkbox
                      indeterminate={selectedRuns.size > 0 && selectedRuns.size < filtered.length}
                      checked={filtered.length > 0 && selectedRuns.size === filtered.length}
                      onChange={toggleAll}
                      size="small"
                    />
                  </TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', color: 'text.secondary' }}>#</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', color: 'text.secondary' }}>PROJET</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', color: 'text.secondary' }}>SIMULATION</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', color: 'text.secondary' }}>DATE</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', color: 'text.secondary' }}>STATUT</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} align="center" sx={{ py: 3, color: 'text.secondary' }}>
                      Aucune exécution disponible.
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map(run => (
                  <TableRow
                    key={run.id} hover
                    selected={selectedRuns.has(run.id)}
                    onClick={() => toggleRunSelection(run.id)}
                    sx={{ cursor: 'pointer' }}
                  >
                    <TableCell padding="checkbox">
                      <Checkbox checked={selectedRuns.has(run.id)} size="small" onChange={() => toggleRunSelection(run.id)} onClick={e => e.stopPropagation()} />
                    </TableCell>
                    <TableCell sx={{ color: 'text.secondary', fontSize: '0.75rem' }}>#{run.id}</TableCell>
                    <TableCell>
                      <Typography variant="caption" fontWeight={500} noWrap sx={{ maxWidth: 120, display: 'block' }}>
                        {run.project?.name ?? '—'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ fontFamily: 'monospace', display: 'block', maxWidth: 200 }} noWrap>
                        {run.simulationClass}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" color="text.secondary">
                        {dayjs(run.startedAt).format('DD/MM/YY HH:mm')}
                      </Typography>
                    </TableCell>
                    <TableCell><StatusChip status={run.status} /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {selectedRuns.size > 0 && (
            <Typography variant="caption" color="primary" sx={{ mt: 1, display: 'block' }}>
              {selectedRuns.size} exécution(s) sélectionnée(s)
            </Typography>
          )}
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={() => setAttachOpen(false)} color="inherit">Annuler</Button>
          <Button
            variant="contained"
            startIcon={<AttachFileIcon />}
            onClick={handleAttachSubmit}
            disabled={!attachedFile || selectedRuns.size === 0}
          >
            Associer la pièce jointe
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar feedback */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar(s => ({ ...s, open: false }))} variant="filled">
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  )
}